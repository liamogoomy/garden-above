﻿
/*NOTE: 
 *This code is based on Dapper Dino's tutorials :)
 */

namespace GCUWebGame.Events
{
    //Seems pointless, BUT data needs to be passed through even if it's nothing..
    [System.Serializable] public struct Void { }
}
