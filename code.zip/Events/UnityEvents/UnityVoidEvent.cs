﻿using UnityEngine.Events;

/*NOTE: 
 *This code is based on Dapper Dino's tutorials :)
 */

namespace GCUWebGame.Events
{
    [System.Serializable] public class UnityVoidEvent : UnityEvent<Void> { }
}
