﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour
{
    public Animator transition;
    AsyncOperation load = null;
public void PlayGame()
    {
        load = SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex + 1);
        load.allowSceneActivation = false;
    }

    public void Update()
    {
        if(load != null)
        {
            StartCoroutine(Fade());
        }


    }
    public void QuitGame ()
    {
        Debug.Log("QUIT!!");
        Application.Quit();
    }

    IEnumerator Fade()
    {
        yield return new WaitForSeconds(10);
        load.allowSceneActivation = true;
    }

}
