﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TravelMenu : MonoBehaviour
{
    public static bool GameIsPaused = false;
    public GameObject TravelMenu1;
    public GameObject TravelMenu2;
    public GameObject missingFlowerMenu;
    public GameObject Ship;
    public GameObject ShipPos1;
    public GameObject ShipPos2;
    public GameObject crosshair;
    public BoxCollider island1;
    public BoxCollider island2;
    public GameObject spawn1 = null;
    public GameObject spawn2 = null;
    public TravellingCutscene cutscene;
    public GameObject cam = null;
    public GameObject player = null;
    public Animator transition;
    public GameObject waterLily = null;
    [SerializeField] GCUWebGame.Player.playerMovement movement = null;
    //public GameObject compendium;


    public void Resume()
    {
        crosshair.SetActive(true);
        Time.timeScale = 1F;
        GameIsPaused = false;
        AudioListener.pause = false;

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
    void Pause()
    {
        AudioListener.pause = true;

        crosshair.SetActive(false);
        //compendium.SetActive(false);
        Time.timeScale = 0F;
        GameIsPaused = true;

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.collider == island1)
        {
            movement.seated = true;
            Pause();
            if (waterLily != null)
            {
                missingFlowerMenu.SetActive(true);
                movement.seated = false;
            }
            else
            {
                TravelMenu1.SetActive(true);
            }
        }
        if (collision.collider == island2)
        {
            movement.seated = true;
            Pause();
            TravelMenu2.SetActive(true);
        }
    }

    public void TravelTo1()
    {
        StartCoroutine(Fade1());

    }
    public void TravelTo2()
    {
        StartCoroutine(Fade2());

    }


    IEnumerator Fade1()
    {
        transition.SetTrigger("Fade");
        TravelMenu2.SetActive(false);
        Time.timeScale = 1F;
        AudioListener.pause = false;
        yield return new WaitForSeconds(2);
        player.transform.position = spawn1.transform.position;
        Ship.transform.position = ShipPos1.transform.position;
        Ship.transform.rotation = ShipPos1.transform.rotation;
        cam.GetComponent<GCUWebGame.Player.playerCamera>().SetRotation();
        player.transform.rotation = spawn1.transform.rotation;
        movement.seated = false;
        Resume();

    }
    IEnumerator Fade2()
    {
        transition.SetTrigger("Fade");
        TravelMenu1.SetActive(false);
        Time.timeScale = 1F;
        AudioListener.pause = false;
        yield return new WaitForSeconds(2);
        player.transform.position = spawn2.transform.position;
        Ship.transform.position = ShipPos2.transform.position;
        Ship.transform.rotation = ShipPos2.transform.rotation;
        cam.GetComponent<GCUWebGame.Player.playerCamera>().SetRotation();
        player.transform.rotation = spawn2.transform.rotation;
        Resume();
        movement.seated = false;
    }
}
