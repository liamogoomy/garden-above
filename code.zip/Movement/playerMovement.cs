﻿using UnityEngine;

/*NOTE: 
 *This code is based on Dapper Dino's and Infallible Code's tutorials :)
 */

namespace GCUWebGame.Player
{
    public class playerMovement : MonoBehaviour
    {
        [SerializeField] private float speed;
        [SerializeField] private float jumpForce;
        private Rigidbody rb;
        private AudioSource audioSource;
        private bool jumped = false;
        private bool grounded = true;
        public bool seated = false;


        //gets player rigidbody
        private void Start()
        {
            rb = GetComponent<Rigidbody>();
            audioSource = GetComponent<AudioSource>();
        }

        private void Update() {
            //raycast to check if player is functionally grounded
            grounded = Physics.Raycast(transform.position, -Vector3.up, (gameObject.GetComponent<CapsuleCollider>().height) / 2 + 0.2f);
            //if player presses space, set jumped to true
            if (Input.GetKeyDown(KeyCode.Space) && grounded && !seated) {
                jumped = true;
            }
        }
        //utilizes move
        private void FixedUpdate()
        {
            if (!seated)
            {
                Move();
            }
            if(seated)
            {
                audioSource.mute = true;
            }
            else
            {
                audioSource.mute = false;
            }

            
            //apply upwards force to rigidbody if grounded and jumped
            if(jumped) {
                rb.AddForce(0, jumpForce, 0);
                jumped = false;
            }
        }

        //player movement
        private void Move()
        {
            //gets input using input manager built within Unity
            float hAxis = Input.GetAxis("Horizontal");
            float vAxis = Input.GetAxis("Vertical");

            //sprint key speed toggle on Left Shift
            if (Input.GetKey(KeyCode.LeftShift)) {
                speed = 4;
            } else {
                speed = 2;
            }

            //calculates how far player wants to move in certain direction
            Vector3 movement = new Vector3(hAxis, 0, vAxis) * speed * Time.deltaTime;

            //calculate newPos, move where rb is facing
            Vector3 newPosition = rb.position + rb.transform.TransformDirection(movement);

            //move there
            rb.MovePosition(newPosition);

            //audio on/off 
            if (movement != new Vector3(0.0f, 0.0f, 0.0f) & grounded)
            {
                if (!audioSource.isPlaying) audioSource.Play();
            }
            else
            {
                audioSource.Stop();
            }
        }
    }
}