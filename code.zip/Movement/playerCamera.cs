﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.PlayerLoop;

/*NOTE: 
 *This code is based on Dapper Dino's and Infallible Code's tutorials :)
 */

namespace GCUWebGame.Player
{
    public class playerCamera : MonoBehaviour
    {
        [SerializeField] private float sensitivity;
        [SerializeField] private float smoothing;
        [SerializeField] private float clampY = 60;
        [SerializeField] public float clampX1 = 180;
        [SerializeField] public float clampX2 = 180;
        public bool xClamp = false;

        private GameObject player;
        private Vector2 smoothedVelocity;
        private Vector2 currentLookingPosition;

        [SerializeField]
        GameObject inventoryCanvas = null, pauseMenu = null, audioMenu = null, compendiumCanvas = null, travelMenu1 = null, travelMenu2 = null, travelFlowerMenu = null;

        private void Start()
        {
            player = transform.parent.gameObject;
            currentLookingPosition = player.transform.forward;

            //locks cursor to center of screen, ESC to unlock (will need to disable to use inventory!)
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }

        //allow camera to move if inventory canvas is not active
        private void Update()
        {
            if (inventoryCanvas.activeInHierarchy == false && pauseMenu.activeInHierarchy == false && audioMenu.activeInHierarchy == false && compendiumCanvas.activeInHierarchy == false && travelMenu1.activeInHierarchy == false && travelMenu2.activeInHierarchy == false && travelFlowerMenu.activeInHierarchy == false)
            {
                RotateCamera();
            }
        }

        private void RotateCamera()
        {
            //storing input
            Vector2 inputValues = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));

            //scales input
            inputValues = Vector2.Scale(inputValues, new Vector2(sensitivity * smoothing, sensitivity * smoothing));

            //smoothing, lerp prevents jolting by only going part of the way to value, "linear interpolation": going btwn two values smoothly
            smoothedVelocity.x = Mathf.Lerp(smoothedVelocity.x, inputValues.x, 1f / smoothing);
            smoothedVelocity.y = Mathf.Lerp(smoothedVelocity.y, inputValues.y, 1f / smoothing);

            currentLookingPosition += smoothedVelocity;

            currentLookingPosition.y = Mathf.Clamp(currentLookingPosition.y, -clampY, clampY);
            if (xClamp)
            {
                currentLookingPosition.x = Mathf.Clamp(currentLookingPosition.x, clampX1, clampX2);
            }

            //above code calculates looking, below does the looking
            transform.localRotation = Quaternion.AngleAxis(-currentLookingPosition.y, Vector3.right);
            player.transform.localRotation = Quaternion.AngleAxis(currentLookingPosition.x, player.transform.up);

        }
        
        public void SetRotation()
        {
            currentLookingPosition = new Vector2(90,0);
            player.transform.localRotation = Quaternion.AngleAxis(currentLookingPosition.x, player.transform.up);
        }
    }
}