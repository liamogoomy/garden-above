﻿using UnityEngine;

/*NOTE: 
 *This code is based on Dapper Dino's tutorials :)
 */
namespace GCUWebGame.Inventory
{
    public abstract class HotBarItem : ScriptableObject
    {
        [Header("Basic Info")]
        [SerializeField] public string itemName = "New Item Name";
        [SerializeField] public Sprite icon = null;
        [SerializeField] public string type = "Type";
        public InventoryItem inventoryItem;

        //external class can only get name, not change it
        public string Name => itemName;
        public abstract string ColoredName 
        { get; }

        public Sprite Icon => icon;

        //info displayed for each item
        public abstract string GetInfoDisplayText();
    }
}
