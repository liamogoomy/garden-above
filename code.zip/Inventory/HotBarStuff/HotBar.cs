﻿using UnityEngine;

/*NOTE: 
 *This code is based on Dapper Dino's tutorials :)
 */
namespace GCUWebGame.Inventory
{
    public class HotBar : MonoBehaviour
    {
       [SerializeField] HotBarSlot[] hotBarSlots;

        public bool Add(HotBarItem itemToAdd)
        {
            //checks slots to see if item can be held
            foreach (HotBarSlot hotBarSlot in hotBarSlots)
            {
                //stop checking
                if (hotBarSlot.AddItem(itemToAdd))
                {
                    return true;
                }
            }
            return false;
        }

        public void updateUI(ItemSlot itemSlot)
        {
            foreach (HotBarSlot hotBarSlot in hotBarSlots)
            {
                hotBarSlot.SetItemQuantityUI();
            }
        }

        //necessary?
        public int Length()
        {
            return hotBarSlots.Length;
        }

        public HotBarSlot returnById(int id)
        {
            return hotBarSlots[id];
        }

        public bool HasItem(HotBarItem item)
        {

            foreach (HotBarSlot hotBarSlot in hotBarSlots)
            {
                //stop checking
                if (hotBarSlot.SlotItem != null)
                {
                    if (hotBarSlot.SlotItem == item)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }
}