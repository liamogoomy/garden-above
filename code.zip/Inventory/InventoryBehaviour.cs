﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GCUWebGame.Inventory
{
    public class InventoryBehaviour : MonoBehaviour, IItemContainer
    {
        [SerializeField] public Inventory inventory = null;
        [SerializeField] private HotBar hb = null;


        private void Start()
        {
            inventory.SetSize(20);
        }

        public ItemSlot AddItem(ItemSlot itemSlot)
        {
            //Please, dont change the order of these lines, important!
            ItemSlot ItemSlot = inventory.AddItem(itemSlot);

            if (!hb.HasItem((HotBarItem)itemSlot.item))
            {
                hb.Add((HotBarItem)itemSlot.item);
            }
            return ItemSlot;
        }

        public void decreaseCount(ItemSlot itemSlot)
        {
            inventory.decreaseCount(itemSlot);
            hb.updateUI(itemSlot);
        }

        public int GetTotalQuantity(InventoryItem item)
        {
            return inventory.GetTotalQuantity(item);
        }

        public bool HasItem(InventoryItem item)
        {
            return inventory.HasItem(item);
        }

        public void RemoveAt(int slotIndex)
        {
            inventory.RemoveAt(slotIndex);
        }

        public void RemoveItem(ItemSlot itemSlot)
        {
            inventory.RemoveItem(itemSlot);
        }

        public void Swap(int indexOne, int indexTwo)
        {
            inventory.Swap(indexOne, indexTwo);
        }
    }
}
