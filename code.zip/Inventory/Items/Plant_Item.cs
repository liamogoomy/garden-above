﻿using System.Text;
using UnityEngine;

/*NOTE:
 *This code is based on Dapper Dino's tutorials :)
 */

namespace GCUWebGame.Inventory
{
    [CreateAssetMenu(fileName = "New Plant Item", menuName = "Items/Plants")]

    public class Plant_Item : InventoryItem
    {
        [Header("Plant")]
        [SerializeField] public string useText = "Grows something?";

        //[SerializeField] public new string itemName = "Plant Name";
        //[SerializeField] public string plantName = "Plant Name";

        [SerializeField] public GameObject flowerPF;
        [SerializeField] public GameObject leavesPF;
        [SerializeField] public GameObject stemPF;
        public GameObject flower;
        [SerializeField] public string code;
        [SerializeField] public Inventory playerInventory = null;
        [SerializeField] public FlowerCodeManager flowerManager = null;

        private void OnEnable()
        {
            //playerInventory = GameObject.FindGameObjectWithTag("Player").GetComponent<InventoryBehaviour>().inventory;
        }

        public override string GetInfoDisplayText()
        {
            StringBuilder builder = new StringBuilder();

           //builder.Append(Name).AppendLine();
            builder.Append("<color=green>").Append(useText).Append("</color>").AppendLine();
            builder.Append("Max Stack: ").Append(MaxStack).AppendLine();

            return builder.ToString();
        }

        public override void Use()
        {
            Debug.Log("using");

            if (!Cursor.visible)
            {
                Plant();
            }
            
        }

        void Plant()
        {
            ItemSlot t = new ItemSlot();
            t.item = this;
            t.quantity = 1;
            
            if (flowerPF != null)
            {
                RaycastHit hit;
                Ray ray = Camera.main.ScreenPointToRay(new Vector2(Screen.width / 2, Screen.height / 2));
                if (Physics.Raycast(ray, out hit))
                {
                    
                    Transform objectHit = hit.transform;


                    if (type != "water")
                    {
                        if (objectHit.tag == "Terrain")
                        {
                            //Debug.Log("planting");
                            flower = SpawnAt();
                            
                            flower.transform.position = hit.point;
                            playerInventory.decreaseCount(t);
                            //randomize z axis
                            Vector3 euler = flower.transform.eulerAngles;
                            euler.y = Random.Range(0.0f, 360.0f);
                            flower.transform.eulerAngles = euler;


                        }
                        else if (objectHit.tag == "Pot")
                        {
                            flower = SpawnAt();
                            //Debug.Log("Pot found, planting in there");
                            Pot tempPot = objectHit.gameObject.GetComponent<Pot>();

                            if (tempPot.plant == null)
                            {
                                tempPot.PlantFlower(flower);
                                playerInventory.decreaseCount(t);
                            }

                        }
                    }
                    else
                    {
                        if (objectHit.tag == "Water")
                        {

                            flower = SpawnAt();
                            //Debug.Log("planting in water");
                            flower.transform.position = hit.point;
                            playerInventory.decreaseCount(t);
                            //randomize z axis
                            Vector3 euler = flower.transform.eulerAngles;
                            euler.y = Random.Range(0.0f, 360.0f);
                            flower.transform.eulerAngles = euler;


                        }
                        else if (objectHit.tag == "WaterPot")
                        {
                            flower = SpawnAt();
                            //Debug.Log("WaterPot found, planting in there");
                            Pot tempPot = objectHit.gameObject.GetComponent<Pot>();

                            if (tempPot.plant == null)
                            {
                                tempPot.PlantFlower(flower);
                                playerInventory.decreaseCount(t);
                            }

                        }
                    }
                }
            }
            else
            {
                Debug.Log("missing flower prefab");
            }
        }

        public GameObject SpawnAt()
        {

            //Debug.Log("planting hybrid");
            int position = DoesFlowerExist(code);
            flower = Instantiate(flowerManager.flowers[position]);
            flower.name = itemName;
            /*
            Child.AddComponent<GCUWebGame.Inventory.Pickup>();

            Child.AddComponent<FlowerCreator>();
            FlowerCreator fc = Child.GetComponent<FlowerCreator>();
            fc.flowerPF = flowerPF;
            fc.leavesPF = leavesPF;
            fc.stemPF = stemPF;


            GCUWebGame.Inventory.Plant_Item item = ScriptableObject.CreateInstance<GCUWebGame.Inventory.Plant_Item>();
            item.itemName = "Mixed Flower";
            item.useText = "A mixed flower";
            item.type = "mixed";
            item.icon = this.icon;
            item.flowerPF = flowerPF;
            item.leavesPF = leavesPF;
            item.stemPF = stemPF;
            item.playerInventory = GameObject.FindGameObjectWithTag("Player").GetComponent<InventoryBehaviour>().inventory;
            item.inventoryItem = item;
            Child.GetComponent<GCUWebGame.Inventory.Pickup>().itemSlot.item = item;
            Child.GetComponent<GCUWebGame.Inventory.Pickup>().itemSlot.quantity = 1;

            fc.BuildFlower(true);
            */
            return flower;
        }

        public int DoesFlowerExist(string code)
        {
            for (int i = 0; i < flowerManager.codes.Count; i++)
            {
                if (flowerManager.codes[i] == code)
                {
                    return i;
                }
            }
            return -1;
        }
    }
}
