﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace GCUWebGame.Inventory
{
    public class Pickup : MonoBehaviour
    {
        [SerializeField] public ItemSlot itemSlot = new ItemSlot();
        private AudioSource pickupSound;
    }
}
