﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class StartingCutscene : MonoBehaviour
{
    public GameObject player = null;
    public GameObject cam = null;
    public GCUWebGame.Player.playerCamera camScript = null;
    public GameObject spawn = null;
    public Volume v = null;
    private Bloom bloom = null;
    public GameObject wind1 = null;
    public GameObject wind2 = null;
    private int counter = 0;

    [SerializeField] public Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        cam.SetActive(true);
        player.SetActive(false);
        v.profile.TryGet(out bloom);
        //bloom.scatter.value = 0.0f;
        //bloom.intensity.value = 1.0f;
        counter = 0;
        StartCoroutine(FinishScene());

    }
    void Update()
    {
        if (counter < 600)
        {
            //bloom.intensity.value += 0.00067f;
            //bloom.scatter.value += 0.00167f;
            counter += 1;
        }
    }

    IEnumerator FinishScene()
    {
        yield return new WaitForSeconds(10);
        //bloom.scatter.value = 1.0f;
        //bloom.intensity.value = 4.0f;
        player.transform.position = spawn.transform.position;
        camScript.SetRotation();
        player.SetActive(true);
        player.transform.position = spawn.transform.position;
        camScript.SetRotation();
        cam.SetActive(false);
        anim.enabled = false;
        wind1.SetActive(false);
        wind2.SetActive(false);
    }
}
