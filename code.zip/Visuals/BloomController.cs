﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class BloomController : MonoBehaviour
{
    private int startCounter = 0;
    public Volume v = null;
    private Bloom bloom = null;
    public bool isDone = false;

    // Start is called before the first frame update
    void Start()
    {
        v.profile.TryGet(out bloom);
        bloom.scatter.value = 0.0f;
        bloom.intensity.value = 1.0f;
        startCounter = 0;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (startCounter < 600)
        {
            bloom.intensity.value = bloom.intensity.value + 0.00067f;
            bloom.scatter.value = bloom.scatter.value + 0.00167f;
            startCounter += 1;
        }
        if (startCounter == 600 && isDone == false)
        {
            bloom.intensity.value = 2;
            bloom.scatter.value = 1;
            isDone = true;
        }
    }
}
