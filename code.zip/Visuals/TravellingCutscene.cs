﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TravellingCutscene : MonoBehaviour
{
    public GameObject player = null;
    public GameObject cam = null;
    public GCUWebGame.Player.playerCamera camScript = null;
    public GameObject spawn = null;
    private int counter = 0;

    [SerializeField] public Animator anim;


    public void StartCutscene()
    {
        cam.SetActive(true);
        player.SetActive(false);
        StartCoroutine(FinishScene());
    }

    IEnumerator FinishScene()
    {
        yield return new WaitForSeconds(10);
        player.transform.position = spawn.transform.position;
        camScript.SetRotation();
        player.SetActive(true);
        player.transform.position = spawn.transform.position;
        camScript.SetRotation();
        cam.SetActive(false);
        anim.enabled = false;
    }
}
