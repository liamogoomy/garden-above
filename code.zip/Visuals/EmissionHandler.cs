﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EmissionHandler : MonoBehaviour
{
    //Input Light through serialized field
    [SerializeField] private Material[] material = null;
    private float TimeOfDay;
    TimeManagement timeManager = null;
    private int[] repitions;
    //How much it brightens during dusk (Default is 100), more repitions means brighter
    [SerializeField] int duskRepeats = 100;
    //How much it dims during dawn (default is 60), more repitions means darker
    [SerializeField] int dawnRepeats = 60;
    //Default dimmingValue (emission multiplied by this at dawn) is 0.95f
    [SerializeField] float dimmingValue = 0.95f;
    //Default brightenValue (emission multiplied by this at dusk) is 1.03f
    [SerializeField] float brightenValue = 1.03f;

    private void Start()
    {
        timeManager = GetComponentInParent<TimeManagement>();
        repitions = new int[material.Length];
    }
    // Update is called once per frame
    void FixedUpdate()
    {
        //Get time of day from parent
        TimeOfDay = timeManager.TimeOfDay;
        if (Application.isPlaying)
        {
            //Updates based on the time of day split up in 24f
            UpdateEmission(TimeOfDay / 24f);
        }
        else
        {
            UpdateEmission(TimeOfDay / 24f);
        }
    }

    private void UpdateEmission(float timePercent)
    {
        for (int count = 0; count < material.Length; count++)
        {
            if (material != null)
            {
                //resets the repitions of the current material to 0 so it can repeat next cycle
                if (timePercent > 0.35f && timePercent < 0.75f)
                {
                    repitions[count] = 0;
                }
                if (timePercent > 0f && timePercent < 0.15f)
                {
                    repitions[count] = 0;
                }
                //Checks if it is turning into night or day
                //Dims the light if it is turning into day
                else if (timePercent < 0.25f && timePercent > 0.15f)
                {
                    if (repitions[count] < dawnRepeats)
                    {
                        material[count].SetFloat("EmiStr", material[count].GetFloat("EmiStr") * dimmingValue);
                        repitions[count]++;
                    }
                }
                //Brightens emission at nighttime
                else if (timePercent < 0.9f && timePercent > 0.8f)
                {
                    if (repitions[count] < duskRepeats)
                    {
                        material[count].SetFloat("EmiStr", material[count].GetFloat("EmiStr") * brightenValue);
                        repitions[count]++;
                    }
                }
                //Makes sure emission is properly off at daytime and that engine confirms it
                else if (timePercent > 0.26f && timePercent < 0.34f && repitions[count] < 1)
                {
                    material[count].EnableKeyword("FLOWEREMISSION");
                    material[count].SetFloat("EmiStr", 0);
                    material[count].globalIlluminationFlags = MaterialGlobalIlluminationFlags.EmissiveIsBlack;
                    RendererExtensions.UpdateGIMaterials(GetComponent<Renderer>());
                    DynamicGI.UpdateEnvironment();
                    repitions[count]++;
                }
                //Makes sure emission is properly on at nighttime and that engine confirms it
                else if (timePercent < 0.8f && timePercent > 0.75f && repitions[count] < 1)
                {
                    material[count].EnableKeyword("FLOWEREMISSION");
                    material[count].SetFloat("EmiStr", 0.1f);
                    material[count].globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
                    RendererExtensions.UpdateGIMaterials(GetComponent<Renderer>());
                    DynamicGI.UpdateEnvironment();
                    repitions[count]++;
                }
            }
        }
    }
}
