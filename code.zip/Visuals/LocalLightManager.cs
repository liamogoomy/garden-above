﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LocalLightManager : MonoBehaviour
{
    //Input Light through serialized field
    [SerializeField] private Light SpotLight = null;
    private float TimeOfDay;
    [SerializeField] private float intensity = 1f;
    TimeManagement timeManager = null;
    private float intensityChange = 0f;
    //private AudioSource dayAmbience;
    //private AudioSource nightAmbience;

    private void Start()
    {
        intensityChange = intensity / 200f;
        timeManager = GetComponentInParent<TimeManagement>();
        //dayAmbience = GetComponent<AudioSource>();
        //nightAmbience = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //Get time of day from parent
        TimeOfDay = timeManager.TimeOfDay;
        if (Application.isPlaying)
        {
            UpdateLighting(TimeOfDay / 24f);
        }
        else
        {
            UpdateLighting(TimeOfDay / 24f);
        }
    }

    private void UpdateLighting(float timePercent)
    {
        if (SpotLight != null)
        {
            //Checks if it is turning into night or day
            if (timePercent < 0.3f || timePercent > 0.8f)
            {
                //Dims the light if it is turning into day
                if (timePercent < 0.3f && timePercent > 0.2f)
                {
                    SpotLight.intensity -= intensityChange;
                    
                    //Debug.Log("Day " + TimeOfDay);
                }
                //turns on light if it is turning into night
                else if (timePercent < 0.9f && timePercent > 0.8f && SpotLight.intensity < intensity)
                {
                    SpotLight.intensity += intensityChange;

                    //Debug.Log("Night " + TimeOfDay);
                }
                //if it otherwise fails it turns on the light
                else 
                {
                    SpotLight.intensity = intensity;
                }
                
            }
            //turns off lights
            else
            {
                SpotLight.intensity = 0;
            }
        }

    }
}
