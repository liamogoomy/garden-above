﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class BloomTimeController : MonoBehaviour
{
    private int startCounter = 0;
    public Volume v = null;
    private Bloom bloom = null;
    [SerializeField] private float intensity = 4f;
    private float TimeOfDay;
    [SerializeField] TimeManagement timeManager = null;
    private float intensityChange = 0f;

    // Start is called before the first frame update
    void Start()
    {
        v.profile.TryGet(out bloom);
        bloom.scatter.value = 0.0f;
        bloom.intensity.value = 1.0f;
        startCounter = 0;
        intensityChange = (intensity-2) / 600f;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        TimeOfDay = timeManager.TimeOfDay;
        if (Application.isPlaying)
        {
            UpdateBloom(TimeOfDay / 24f);
        }
        else
        {
            UpdateBloom(TimeOfDay / 24f);
        }
    }

    private void UpdateBloom(float timePercent)
    {
        if (bloom != null)
        {
            //Checks if it is turning into night or day
            if (timePercent < 0.3f || timePercent > 0.8f)
            {
                bloom.threshold.value = 0.8f;
                //Dims the light if it is turning into day
                if (timePercent < 0.3f && timePercent > 0.2f && startCounter < 600)
                {
                    bloom.intensity.value -= intensityChange;
                    startCounter += 1;
                    //Debug.Log("Day " + TimeOfDay);
                }
                //turns on light if it is turning into night
                else if (timePercent < 0.9f && timePercent > 0.8f && bloom.intensity.value < intensity && startCounter < 600)
                {
                    bloom.intensity.value += intensityChange;
                    startCounter += 1;
                    //Debug.Log("Night " + TimeOfDay);
                }
                
                else if (timePercent > 0.9f || timePercent < 0.2f && startCounter != 0)
                {
                    startCounter = 0;
                }
                //if it otherwise fails it turns on the light
                else
                {
                    bloom.intensity.value = intensity;
                }
                

            }
            //turns off lights
            else if (timePercent > 0.3f || timePercent < 0.8f)
            {
                bloom.threshold.value = 1.35f;
                bloom.intensity.value = 2;
            }
        }

    }
}
