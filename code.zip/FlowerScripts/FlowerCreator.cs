﻿

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;


#if (UNITY_EDITOR)
[CustomEditor(typeof(FlowerCreator))]
public class FlowerCreatorEditor : Editor
{
    bool firstBuild = false;
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        FlowerCreator myTarget = (FlowerCreator)target;

        if (GUILayout.Button("Build Flower"))
        {
            if (firstBuild)
            {
                myTarget.ClearFlower();
            }
            else
            {
                firstBuild = true;
            }
            myTarget.BuildFlower(firstBuild);
            
        }

        //myTarget.experience = EditorGUILayout.IntField("Experience", myTarget.experience);
        //EditorGUILayout.LabelField("Level", myTarget);
    }


}
#endif
public class FlowerCreator : MonoBehaviour
{
    [SerializeField]
    public GameObject stemPF, flowerPF, leavesPF;
    public GameObject currStem;
    public string code;
    public string namePart1;
    public string namePart2;
    public string namePart3;
    List<Transform> flowerSlots, leavesSlots;

    public void BuildFlower(bool first)
    {

        if (!first)
        {
            ClearFlower();
        }
        currStem = Instantiate(stemPF, transform);
        currStem.transform.localPosition = Vector3.zero;
        Stem s = currStem.GetComponent<Stem>();
        flowerSlots = new List<Transform>();
        leavesSlots = new List<Transform>();
        flowerSlots.AddRange(s.flowers);
        leavesSlots.AddRange(s.leaves);
        
        foreach(Transform sl in flowerSlots)
        {

                Instantiate(flowerPF, sl);

        }
        foreach (Transform sl in leavesSlots)
        {

                Instantiate(leavesPF, sl);

            
        }
    }
    public void ClearFlower()
    {
        flowerSlots.Clear();
        leavesSlots.Clear();
        GameObject.DestroyImmediate(GetComponent<Transform>().GetChild(0).gameObject);
    }
}

