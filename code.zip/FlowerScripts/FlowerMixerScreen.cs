﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FlowerMixerScreen : MonoBehaviour
{
    [SerializeField] private FlowerCreator FlowerParent1 = null;
    [SerializeField] private FlowerCreator FlowerParent2 = null;
    [SerializeField] FlowerMixerMachine machine = null;
    [SerializeField] private Image FlowerImageSlot1 = null;
    [SerializeField] private Image FlowerImageSlot2 = null;
    [SerializeField] private Image FlowerImageResult = null;
    [SerializeField] private Image ProgressBar = null;
    [SerializeField] RuntimeIconGenerator iconGen = null;
    // Start is called before the first frame update
    void Start()
    {


    }

    // Update is called once per frame
    void FixedUpdate()
    {

        if (ProgressBar.fillAmount < 0.999f)
        {
            UpdateBar();
        }
    }

    public void ReadFlowers()
    {
        FlowerParent1 = machine.FlowerParent1;
        FlowerParent2 = machine.FlowerParent2;
    }

    public void UpdateScreen()
    {
        StartCoroutine(ShortDelay());
        FlowerImageSlot1.sprite = FlowerParent1.GetComponentInParent<GCUWebGame.Inventory.Pickup>().itemSlot.item.icon;
        FlowerImageSlot2.sprite = FlowerParent2.GetComponentInParent<GCUWebGame.Inventory.Pickup>().itemSlot.item.icon;
        StartCoroutine(Delay());
    }
    
    public void UpdateScreenNoNew(GameObject flower)
    {
        StartCoroutine(ShortDelay());
        FlowerImageSlot1.sprite = FlowerParent1.GetComponentInParent<GCUWebGame.Inventory.Pickup>().itemSlot.item.icon;
        FlowerImageSlot2.sprite = FlowerParent2.GetComponentInParent<GCUWebGame.Inventory.Pickup>().itemSlot.item.icon;
        StartCoroutine(Delay2(flower));
    }

    public void ResetBar()
    {
        ProgressBar.fillAmount = 0;
    }
    private void UpdateBar()
    {
        ProgressBar.fillAmount += 0.009f;
    }

    IEnumerator Delay()
    {
        yield return new WaitForSeconds(2.3f);
        //FlowerImageResult.GetComponentInChildren<Image>().sprite = Child.GetComponent<GCUWebGame.Inventory.Pickup>().itemSlot.item.icon;
        FlowerImageResult.sprite = Sprite.Create(iconGen.icon, new Rect(Vector2.zero, new Vector2(128, 128)), Vector2.zero);
    }

    IEnumerator Delay2(GameObject flower)
    {
        yield return new WaitForSeconds(2.3f);
        //FlowerImageResult.GetComponentInChildren<Image>().sprite = Child.GetComponent<GCUWebGame.Inventory.Pickup>().itemSlot.item.icon;
        FlowerImageResult.sprite = flower.GetComponent<GCUWebGame.Inventory.Pickup>().itemSlot.item.icon;
    }

    IEnumerator ShortDelay()
    {
        yield return new WaitForSeconds(0.2f);
    }
}
