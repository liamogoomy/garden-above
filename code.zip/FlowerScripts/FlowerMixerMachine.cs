﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GCUWebGame;

public class FlowerMixerMachine : MonoBehaviour
{

    [SerializeField] public FlowerCreator FlowerParent1 = null;
    [SerializeField] public FlowerCreator FlowerParent2 = null;
    [SerializeField] private FlowerCreator FlowerResult = null;
    public GameObject Child = null;
    public bool genButton = false;
    public bool printButton = false;
    bool reset = false;
    bool occupied = false;
    //[SerializeField] private GameObject FlowerSlot1 = null;
    //[SerializeField] private GameObject FlowerSlot2 = null;
    [SerializeField]  Pot FlowerEject = null;
    [SerializeField] private GameObject FlowerCamEject = null;
    [SerializeField] private RuntimeIconGenerator iconGen = null;
    [SerializeField] private GameObject FlowerResultObject = null;
    [SerializeField] private Pot first, second;
    [SerializeField] private GameObject lastPlant = null;
    [SerializeField] private FlowerMixerScreen screen = null;
    private Bounds childBounds;
    private string code = null;
    private string flowerName = null;
    private string name1 = null;
    private string name2 = null;
    private string name3 = null;
    private int position;
    GCUWebGame.Inventory.Pickup childItem = null;
    FlowerCreator childFlower = null;
    GCUWebGame.Inventory.Plant_Item item = null;
    [SerializeField] GCUWebGame.Inventory.InventoryBehaviour inv;
    [SerializeField] private FlowerCodeManager flowerManager = null;

    private void Start()
    {
        FlowerResultObject = new GameObject("NewFlowerInformation");
        FlowerResultObject.AddComponent<FlowerCreator>();
        FlowerResult = FlowerResultObject.GetComponent<FlowerCreator>();
        Child = new GameObject("Flower");
        childItem = Child.AddComponent<GCUWebGame.Inventory.Pickup>();
        childFlower = Child.AddComponent<FlowerCreator>();
        item = ScriptableObject.CreateInstance<GCUWebGame.Inventory.Plant_Item>();
    }
    private void Update()
    {
        if(first.plant == null || second.plant == null || reset)
        {
            reset = true;
        }
        if (reset && first.plant != null && second.plant != null)
        {
            genButton = true;
            reset = false;
        }

        //if (Input.GetKeyDown(KeyCode.Return))
        if (printButton == true && FlowerEject.plant == null)
        {
            position = DoesFlowerExist(code);
            if (position != -1 && code != null)
            {
                OutputCreatedFlower(position);
            }
            else
            {
                OutputRealFlower();
            }
                
            printButton = false;
        }
        else
        {
            printButton = false;
        }
        //if (Input.GetKeyDown(KeyCode.G))
        if (genButton == true)
        {
            ReadFlowers();
            MixFlowers();
            screen.ReadFlowers();
            screen.ResetBar();
            position = DoesFlowerExist(code);
            if (position != -1 && code != null)
            {
                FetchIconFlower(position);
                screen.UpdateScreenNoNew(lastPlant);
            }
            else
            {
                OutputIconFlower();
                iconGen.FitCamera(childBounds);
                iconGen.GenerateIcon();
                screen.UpdateScreen();
                Destroy(Child.transform.GetChild(0).gameObject);
            }
            genButton = false;
        }
    }

    public void GenButtonPress()
    {
        genButton = true;
    }
    private void ReadFlowers()
    {
        FlowerParent1 = first.plant.GetComponent<FlowerCreator>();
        FlowerParent2 = second.plant.GetComponent<FlowerCreator>();

    }


    private void MixFlowers()
    {
        code = null;
        int Choice1 = 0;
        int Choice2 = 0;
        string part1 = "";
        string part2 = "";
        string part3 = "";
        name1 = "";
        name2 = "";
        name3 = "";

        if (Random.value >= 0.5f)
        {
            FlowerResult.flowerPF = FlowerParent1.flowerPF;
            Choice1 = 1;
            part1 = FlowerParent1.code.Substring(0, 2);
            name3 = FlowerParent1.namePart3;
        }
        else
        {
            FlowerResult.flowerPF = FlowerParent2.flowerPF;
            Choice1 = 2;
            part1 = FlowerParent2.code.Substring(0, 2);
            name3 = FlowerParent2.namePart3;
        }

        if (Choice1 == 1)
        {

            if (Random.value >= 0.75f)
            {
                FlowerResult.leavesPF = FlowerParent2.leavesPF;
                Choice2 = 1;
                part2 = FlowerParent1.code.Substring(2, 2);
                name2 = FlowerParent1.namePart2;
            }
            else
            {
                FlowerResult.leavesPF = FlowerParent1.leavesPF;
                Choice2 = 2;
                part2 = FlowerParent2.code.Substring(2, 2);
                name2 = FlowerParent2.namePart2;
            }
            
        }
        else if(Choice1 == 2)
        {
            
            if(Random.value >= 0.25f)
            {
                FlowerResult.leavesPF = FlowerParent1.leavesPF;
                Choice2 = 1;
                part2 = FlowerParent1.code.Substring(2, 2);
                name2 = FlowerParent1.namePart2;
            }
            else
            {
                FlowerResult.leavesPF = FlowerParent2.leavesPF;
                Choice2 = 2;
                part2 = FlowerParent2.code.Substring(2, 2);
                name2 = FlowerParent2.namePart2;
            }
            
        }
        
        if(Choice1 == 1 && Choice2 == 1)
        {
            FlowerResult.stemPF = FlowerParent2.stemPF;
            part3 = FlowerParent2.code.Substring(4, 2);
            name1 = FlowerParent2.namePart1;
        }
        else if(Choice1 == 2 && Choice2 == 2)
        {
            FlowerResult.stemPF = FlowerParent1.stemPF;
            part3 = FlowerParent1.code.Substring(4, 2);
            name1 = FlowerParent1.namePart1;
        }
        else
        {
            if (Random.value >= 0.5f)
            {
                FlowerResult.stemPF = FlowerParent1.stemPF;
                part3 = FlowerParent1.code.Substring(4, 2);
                name1 = FlowerParent1.namePart1;
            }
            else
            {
                FlowerResult.stemPF = FlowerParent2.stemPF;
                part3 = FlowerParent2.code.Substring(4, 2);
                name1 = FlowerParent2.namePart1;
            }
        }
        code = part1 + part2 + part3;
        flowerName = name1 + name2 + name3;
    }

    public void OutputIconFlower()
    {
        //Destroy(lastPlant);
        //Child = new GameObject(flowerName);
        //GCUWebGame.Inventory.Pickup childItem = Child.AddComponent<GCUWebGame.Inventory.Pickup>();
        Child.layer = 11;
        //FlowerCreator childFlower = Child.AddComponent<FlowerCreator>();
        childFlower.flowerPF = FlowerResult.flowerPF;
        childFlower.leavesPF = FlowerResult.leavesPF;
        childFlower.stemPF = FlowerResult.stemPF;
        childFlower.code = code;
        childFlower.flowerPF.layer = 11;
        childFlower.leavesPF.layer = 11;
        childFlower.stemPF.layer = 11;

        //GCUWebGame.Inventory.Plant_Item item = ScriptableObject.CreateInstance<GCUWebGame.Inventory.Plant_Item>();
        item.itemName = flowerName;
        item.useText = "A hybrid flower";
        item.type = "mixed";
        item.inventoryItem = item;
        childItem.itemSlot.item = item;
        childItem.itemSlot.quantity = 1;

        
        Child.transform.position = FlowerCamEject.transform.position;
        //var newPlant = Instantiate(Child, FlowerCamEject.transform);
        childFlower.BuildFlower(true);
        Child.layer = LayerMask.NameToLayer("Icon");
        
        foreach (Animator element in Child.GetComponent<FlowerCreator>().flowerPF.GetComponentsInChildren<Animator>()) //lastPlant.GetComponentsInChildren<Animator>()
        {
            element.enabled = false;
            element.enabled = true;
        }
        foreach (Animator element in Child.GetComponent<FlowerCreator>().stemPF.GetComponentsInChildren<Animator>()) //lastPlant.GetComponentsInChildren<Animator>()
        {
            element.enabled = false;
            element.enabled = true;
        }
        
        childFlower.currStem.layer = 11;

        childBounds = childFlower.currStem.GetComponent<BoxCollider>().bounds;
        //lastPlant = newPlant;
        //Destroy(newPlant);
        /*
        foreach (Animator element in lastPlant.GetComponentsInChildren<Animator>()) //lastPlant.GetComponentsInChildren<Animator>()
        {
            element.enabled = false;
        }
        */
    }

    public void OutputRealFlower()
    {
        //Child = new GameObject(flowerName);
        //Child.AddComponent<BoxCollider>();
        Child.layer = 9;
        //GCUWebGame.Inventory.Pickup childItem = Child.AddComponent<GCUWebGame.Inventory.Pickup>();
        //FlowerCreator childFlower = Child.AddComponent<FlowerCreator>();
        childFlower.flowerPF = FlowerResult.flowerPF;
        childFlower.leavesPF = FlowerResult.leavesPF;
        childFlower.stemPF = FlowerResult.stemPF;
        childFlower.code = code;
        childFlower.namePart1 = name1;
        childFlower.namePart2 = name2;
        childFlower.namePart3 = name3;

        //Child.GetComponent<BoxCollider>().center = new Vector3(0, 0.3f, 0);
        //Child.GetComponent<BoxCollider>().size = new Vector3(0.45f, 1f, 0.35f);
        //Child.GetComponent<BoxCollider>().isTrigger = true;

        item = ScriptableObject.CreateInstance<GCUWebGame.Inventory.Plant_Item>();
        item.itemName = flowerName;
        item.useText = "A mixed flower";
        item.type = "mixed";
        // iconTex = new Texture2D(128, 128, TextureFormat.ARGB32, false);
        //iconTex = iconGen.icon;
        item.icon = Sprite.Create(iconGen.icon, new Rect(Vector2.zero, new Vector2(128, 128)), Vector2.zero);
        item.flowerPF = FlowerResult.flowerPF;
        item.leavesPF = FlowerResult.leavesPF;
        item.stemPF = FlowerResult.stemPF;
        item.playerInventory = inv.inventory;
        item.flowerManager = flowerManager;
        item.code = code;
        item.inventoryItem = item;
        childItem.itemSlot.item = item;
        childItem.itemSlot.quantity = 1;

        //Child.GetComponent<Transform>().position = FlowerEject.transform.position;
        Child.layer = LayerMask.NameToLayer("Interactable");
        GameObject createdFlower = new GameObject(flowerName);
        createdFlower = Instantiate(Child);
        createdFlower.transform.position = FlowerEject.spwanPoint.position;
        FlowerEject.plant = createdFlower;
        createdFlower.GetComponent<FlowerCreator>().BuildFlower(true);
        createdFlower.GetComponent<FlowerCreator>().currStem.layer = 9;
        GameObject newFlower = new GameObject(flowerName);
        newFlower = Instantiate(Child);
        newFlower.name = flowerName;
        newFlower.transform.position = new Vector3(0, 0, 0);
        newFlower.GetComponent<FlowerCreator>().BuildFlower(true);
        newFlower.GetComponent<FlowerCreator>().currStem.layer = 9;
        flowerManager.flowers.Add(newFlower);
        flowerManager.codes.Add(code);
        //Instantiate(Child, FlowerEject.transform);
    }

    public void OutputCreatedFlower(int position)
    {
        //Child = new GameObject("temp");
        GameObject createdFlower = new GameObject(flowerName);
        createdFlower = Instantiate(flowerManager.flowers[position]);
        createdFlower.transform.position = FlowerEject.spwanPoint.position;
        FlowerEject.plant = createdFlower;
        Destroy(createdFlower.transform.GetChild(0).gameObject);
        createdFlower.GetComponent<FlowerCreator>().BuildFlower(true);
        createdFlower.layer = LayerMask.NameToLayer("Interactable");
        createdFlower.GetComponent<FlowerCreator>().currStem.layer = 9;
    }

    public void FetchIconFlower(int position)
    {
        //Child = new GameObject("temp");
        lastPlant = flowerManager.flowers[position];
    }

    public int DoesFlowerExist(string code)
    {
        for (int i = 0; i < flowerManager.codes.Count; i++)
        {
            if (flowerManager.codes[i] == code)
            {
                return i;
            }
        }
        return -1;
    }


    IEnumerator SnapDelay()
    {
        yield return new WaitForSeconds(0.1f);
    }
}
