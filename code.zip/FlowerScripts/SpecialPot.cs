﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GCUWebGame.Inventory;

public class SpecialPot : Pot
{
    public float updateRate = 5, width, length, maxFlowers = 4;
    float timer = 0;
    List<GameObject> flowers;
    // Start is called before the first frame update
    void Start()
    {
        flowers = new List<GameObject>();
    }

    // Update is called once per frame
    void Update()
    {
        if(plant != null)
        {
            if (timer > updateRate)
            {
                GrowFlowers();
                timer = 0;
            }
            else
            {
                timer += Time.deltaTime;
            }
        }

    }

    void GrowFlowers()
    {
        if(flowers.Count < maxFlowers)
        {

            Vector3 pos = new Vector3(Random.Range(-width/2, width / 2), 0, Random.Range(-length/2, length / 2));
            RaycastHit hit;
            Ray ray = new Ray(pos + transform.position + new Vector3(0, 1, 0), new Vector3(0, -1, 0));
            //Debug.DrawRay(pos + transform.position, new Vector3(0, -1, 0), Color.green);
            if (Physics.Raycast(ray, out hit))
            {
                Transform objectHit = hit.transform;
                if (objectHit.tag == "Pot")
                {
                    GameObject flower = ((Plant_Item)plant.GetComponent<Pickup>().itemSlot.item).SpawnAt();
                    flower.transform.position = hit.point;
                    //randomize z axis
                    Vector3 euler = flower.transform.eulerAngles;
                    euler.y = Random.Range(0.0f, 360.0f);
                    flower.transform.eulerAngles = euler;
                    flowers.Add(flower);
                }
            }
        }
    }
}
