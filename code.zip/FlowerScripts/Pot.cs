﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GCUWebGame.Inventory;

public class Pot : MonoBehaviour
{
    public GameObject plant;
    public Transform spwanPoint;


    public void PlantFlower(GameObject fl)
    {

            fl.transform.position = spwanPoint.position;
            plant = fl;


    }

}
