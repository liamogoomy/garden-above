﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

/*Attached to the Player, handles the relationship between data and game objects*/

public class Compendium : MonoBehaviour
{
    //land & water flower buttons are needed in these fields
    public GameObject[] landFlowers;
    public GameObject[] waterFlowers;

    //
    public GameObject template;
    public GameObject mixedPage;
    public GameObject compendiumObject;
    private HashSet<string> flowersSet = new HashSet<string>();

    public void landFlower(string flower)
    {
        switch (flower)
        {
            case "Aechmea":
                landFlowers[0].SetActive(true);
                break;

            case "Amaryllis":
                landFlowers[1].SetActive(true);
                break;

            case "Cosmos":
                landFlowers[2].SetActive(true);
                break;

            case "Edelweiss":
                landFlowers[3].SetActive(true);
                break;
            
            case "Exotic":
                landFlowers[4].SetActive(true);
                break;

            case "Harebell":
                landFlowers[5].SetActive(true);
                break;
            
            case "Jade Vine":
                landFlowers[6].SetActive(true);
                break;
            
            case "Lace Leaf":
                landFlowers[7].SetActive(true);
                break;

            case "Rafflesia":
                landFlowers[8].SetActive(true);
                break;

            case "Scarborough Lily":
                landFlowers[9].SetActive(true);
                break;

            case "Succulent":
                landFlowers[10].SetActive(true);
                break;
        }
    }


    public void waterFlower(string flower)
    {
        switch (flower)
        {
            case "ReedsBush":
                waterFlowers[0].SetActive(true);
                break;
            
            case "Water Lily":
                waterFlowers[1].SetActive(true);
                break;
        }
    }

    public void mixedFlower(string flower, Sprite icon)
    {
        if (!flowersSet.Contains(flower))
        {
            flowersSet.Add(flower);
            CompFlowerData test = new CompFlowerData();
            test.name = flower;
            test.description = "A new creation!";
            test.icon = icon;

            template.transform.GetChild(1).transform.GetChild(1).GetComponent<Image>().sprite = icon;

            GameObject createdTemplate = Instantiate(template, mixedPage.transform);

            createdTemplate.transform.GetChild(1).GetComponent<Button>().onClick.AddListener(
                delegate { compendiumObject.GetComponent<CompendiumBehaviour>().UpdateFlowerUI(test); });
        }
    }
}