﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//displays & updates the flower data onto UI
public class CompendiumBehaviour : MonoBehaviour
{
    //public CompFlowerData flowerData
    public Text nameText;

    public Text descriptionText;

    public Image image;

public void UpdateFlowerUI(CompFlowerData flowerDetails)
    {
        Debug.Log("update flower info");
        nameText.text = flowerDetails.name;
        descriptionText.text = flowerDetails.description;

        image.sprite = flowerDetails.icon;
    }
}
