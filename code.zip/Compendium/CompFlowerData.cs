﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//allows creation of flower data :)

[CreateAssetMenu(fileName = "New Flower", menuName = "Flower Data")]
public class CompFlowerData : ScriptableObject
{
    public new string name;
    [TextArea]
    public string description;

    public Sprite icon;

    //parents?
}
